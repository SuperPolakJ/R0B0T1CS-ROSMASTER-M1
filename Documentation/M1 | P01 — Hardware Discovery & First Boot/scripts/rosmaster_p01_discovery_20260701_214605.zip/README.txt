Diagnostic passif P01. Transmettre uniquement après vérification du contenu.
Les données comprennent des noms de périphériques et des extraits de code source.
Aucune information de connexion Wi-Fi, clé privée ou variable d’environnement n’est collectée intentionnellement.
