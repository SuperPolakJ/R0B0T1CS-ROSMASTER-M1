Inspecter les données avant partage. Des noms locaux de services et containers peuvent être présents.
