# R06 — Linux, Docker et démarrage

**Inventaire passif : aucune modification, aucun Node ni moteur activé.**

- Containers listés : 18
- Containers en cours d’exécution : 1
- Métadonnées : images, état, mode réseau, politique de redémarrage, destinations des volumes.
- Services : noms des unités activées et exécutées.
- Limites : inventaire déclaratif, pas une preuve de fonctionnement ROS 2.

- `youthful_matsumoto` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Up 2 hours — réseau=host, restart=no
- `great_dubinsky` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (137) 2 hours ago — réseau=host, restart=no
- `competent_black` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 5 hours ago — réseau=host, restart=no
- `funny_greider` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 5 hours ago — réseau=host, restart=no
- `brave_northcutt` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 5 hours ago — réseau=host, restart=no
- `nice_merkle` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 5 hours ago — réseau=host, restart=no
- `serene_dirac` : `192.168.2.51:5000/ros-humble-m1:1.1.3` — Exited (255) 5 hours ago — réseau=host, restart=no
- `vibrant_galois` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (137) 5 hours ago — réseau=host, restart=no
- `upbeat_goodall` : `192.168.2.51:5000/ros-humble-m1:1.1.3` — Exited (255) 2 days ago — réseau=host, restart=no
- `sad_albattani` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (0) 2 days ago — réseau=host, restart=no
- `ecstatic_mendeleev` : `192.168.2.51:5000/ros-humble-m1:1.1.2` — Exited (129) 2 days ago — réseau=host, restart=no
- `infallible_mestorf` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (0) 2 days ago — réseau=host, restart=no
- `affectionate_swartz` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (0) 2 days ago — réseau=host, restart=no
- `amazing_hofstadter` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (137) 2 days ago — réseau=host, restart=no
- `dazzling_jennings` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 2 days ago — réseau=host, restart=no
- `awesome_engelbart` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 2 days ago — réseau=host, restart=no
- `serene_shockley` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 6 months ago — réseau=host, restart=no
- `boring_easley` : `192.168.2.51:5000/ros-humble-m1:1.1.1` — Exited (255) 6 months ago — réseau=host, restart=no
