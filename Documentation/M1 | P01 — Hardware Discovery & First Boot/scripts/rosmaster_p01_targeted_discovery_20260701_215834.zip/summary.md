# R0B0T1CS LAB — P01 Targeted Discovery v1.1

Container : youthful_matsumoto
Packages inspectés : 17
Extraits statiques : 1777

## Dossiers inspectés et nombre de correspondances
- yahboomcar_base_node: 68 extraits; limite atteinte=False
- yahboomcar_bringup: 150 extraits; limite atteinte=True
- yahboomcar_ctrl: 65 extraits; limite atteinte=False
- yahboomcar_laser: 118 extraits; limite atteinte=False
- yahboomcar_astra: 150 extraits; limite atteinte=True
- yahboomcar_depth: 150 extraits; limite atteinte=True
- yahboomcar_description: 115 extraits; limite atteinte=False
- yahboomcar_nav: 150 extraits; limite atteinte=True
- yahboomcar_vision: 41 extraits; limite atteinte=False
- yahboomcar_msgs: 0 extraits; limite atteinte=False
- yahboomcar_interfaces: 158 extraits; limite atteinte=True
- yahboomcar_voice_ctrl: 150 extraits; limite atteinte=True
- robot_pose_publisher_ros2: 6 extraits; limite atteinte=False
- laserscan_to_point_publisher: 6 extraits; limite atteinte=False
- yahboomcar_multi: 150 extraits; limite atteinte=True
- largemodel: 150 extraits; limite atteinte=True
- multi_brains: 150 extraits; limite atteinte=True

**Vérifier cette archive avant tout partage.**
Aucun mot de passe ni clé privée ne sont collectés intentionnellement.
