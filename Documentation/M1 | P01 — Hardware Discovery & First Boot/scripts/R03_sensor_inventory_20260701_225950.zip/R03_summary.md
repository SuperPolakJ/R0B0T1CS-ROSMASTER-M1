# R03 — Inventaire passif des capteurs et périphériques

Horodatage fourni par le Raspberry Pi : 2026-07-01T22:59:50.332798

> La détection d’un périphérique ne prouve pas que son capteur fonctionne.
> Aucun périphérique série, caméra ou moteur n’a été ouvert.

## USB détectés
```
Bus 004 Device 001: ID 1d6b:0003 Linux Foundation 3.0 root hub
Bus 003 Device 002: ID 0079:181c DragonRise Inc. Controller
Bus 003 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub
Bus 002 Device 001: ID 1d6b:0003 Linux Foundation 3.0 root hub
Bus 001 Device 007: ID 2109:8817 VIA Labs, Inc. USB Billboard Device   
Bus 001 Device 020: ID 1a86:7522 QinHeng Electronics CH340 serial converter
Bus 001 Device 019: ID 0d8c:0012 C-Media Electronics, Inc. USB Audio Device
Bus 001 Device 018: ID 1a86:8091 QinHeng Electronics USB HUB
Bus 001 Device 005: ID 10c4:ea60 Silicon Labs CP210x UART Bridge
Bus 001 Device 004: ID 1a86:7523 QinHeng Electronics CH340 serial converter
Bus 001 Device 017: ID 3482:6723 NOVATEK  ASJ ZNX_NVT
Bus 001 Device 002: ID 2109:2817 VIA Labs, Inc. USB2.0 Hub             
Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub
```

## Interfaces et identifiants persistants
### serial_by_id
- usb-1a86_USB_Serial-if00-port0 → /dev/ttyUSB2
- usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0 → /dev/ttyUSB1
### serial_by_path
- platform-xhci-hcd.0-usb-0:2.2:1.0-port0 → /dev/ttyUSB0
- platform-xhci-hcd.0-usb-0:2.3:1.0-port0 → /dev/ttyUSB1
- platform-xhci-hcd.0-usb-0:2.4.3:1.0-port0 → /dev/ttyUSB2
### video_by_id
- usb-NOVATEK_ASJ_ZNX_NVT_510550000000100-video-index0 → /dev/video0
- usb-NOVATEK_ASJ_ZNX_NVT_510550000000100-video-index1 → /dev/video1
### device_nodes
- /dev/gpiochip0
- /dev/gpiochip10
- /dev/gpiochip11
- /dev/gpiochip12
- /dev/gpiochip13
- /dev/gpiochip4
- /dev/i2c-1
- /dev/i2c-11
- /dev/i2c-13
- /dev/i2c-14
- /dev/i2c-4
- /dev/ttyAMA10
- /dev/ttyUSB0 (USB_Serial)
- /dev/ttyUSB1 (CP2102_USB_to_UART_Bridge_Controller)
- /dev/ttyUSB2 (USB_Serial)
- /dev/video0 (ASJ_ZNX_NVT)
- /dev/video1 (ASJ_ZNX_NVT)
- /dev/video19 ()
- /dev/video20 ()
- /dev/video21 ()
- /dev/video22 ()
- /dev/video23 ()
- /dev/video24 ()
- /dev/video25 ()
- /dev/video26 ()
- /dev/video27 ()
- /dev/video28 ()
- /dev/video29 ()
- /dev/video30 ()
- /dev/video31 ()
- /dev/video32 ()
- /dev/video33 ()
- /dev/video34 ()
- /dev/video35 ()

## Packages Yahboom liés aux capteurs
- **laserscan_to_point_publisher** : 0 fichiers launch ; 0 fichiers YAML
- **yahboomcar_astra** : 0 fichiers launch ; 0 fichiers YAML
- **yahboomcar_base_node** : 0 fichiers launch ; 0 fichiers YAML
- **yahboomcar_bringup** : 5 fichiers launch ; 1 fichiers YAML
- **yahboomcar_ctrl** : 1 fichiers launch ; 0 fichiers YAML
- **yahboomcar_depth** : 1 fichiers launch ; 0 fichiers YAML
- **yahboomcar_description** : 6 fichiers launch ; 0 fichiers YAML
- **yahboomcar_laser** : 0 fichiers launch ; 0 fichiers YAML
- **yahboomcar_vision** : 0 fichiers launch ; 1 fichiers YAML
- **yahboomcar_voice_ctrl** : 0 fichiers launch ; 0 fichiers YAML
- **yahboomcar_voice_ctrl_depth** : 0 fichiers launch ; 0 fichiers YAML

## Limites
- Inventaire sans mesure de données capteurs en temps réel.
- Connexions physiques STM32, IMU, encodeurs, OLED : à confirmer.
- Ne pas déduire une fréquence, une précision ou une disponibilité matérielle d’un nom de package.
- Vérifier le contenu avant partage : les identifiants et chemins matériels peuvent être visibles.
