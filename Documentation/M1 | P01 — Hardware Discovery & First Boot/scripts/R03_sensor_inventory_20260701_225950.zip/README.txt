R03 — inventaire passif (lecture seule).
Vérifier avant partage.
