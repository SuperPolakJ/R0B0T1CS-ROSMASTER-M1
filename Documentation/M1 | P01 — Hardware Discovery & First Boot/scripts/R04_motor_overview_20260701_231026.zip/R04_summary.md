# R04 — Inventaire moteur (statique)

- Container examiné : `youthful_matsumoto`
- Méthode : lecture seule des fichiers ROS 2 Yahboom.
- Aucun Node lancé, aucune commande moteur envoyée.
- Les correspondances montrent le code déclaré, pas les mesures en fonctionnement.

## Fichiers inspectés

- `Mcnamu_driver_M1.py` : ok
- `base_node_M1.cpp` : ok
- `yahboomcar_bringup_M1_launch.py` : ok

## Indices utiles

### Mcnamu_driver_M1.py
- L57: `self.sub_cmd_vel = self.create_subscription(Twist,"cmd_vel",self.cmd_vel_callback,1)`
- L58: `self.sub_RGBLight = self.create_subscription(Int32,"RGBLight",self.RGBLightcallback,100)`
- L59: `self.sub_BUzzer = self.create_subscription(Bool,"Buzzer",self.Buzzercallback,100)`
- L60: `self.sub_Servo = self.create_subscription(ServoControl, "Servo", self.Servo_callback, 10)`
- L63: `self.EdiPublisher = self.create_publisher(String,"edition",100)`
- L64: `self.volPublisher = self.create_publisher(Float32,"voltage",100)`
- L65: `self.staPublisher = self.create_publisher(JointState,"joint_states",100)`
- L66: `self.velPublisher = self.create_publisher(Twist,"vel_raw",50)`
- L67: `self.imuPublisher = self.create_publisher(Imu,"imu/data_raw",100)`
- L68: `self.magPublisher = self.create_publisher(MagneticField,"imu/mag",100)`
- L71: `self.timer = self.create_timer(0.1, self.pub_data)`
- L76: `def cmd_vel_callback(self,msg):`
- L82: `vx = msg.linear.x*1.0`
- L83: `#vy = msg.linear.y/1000.0*180.0/3.1416    #Radian system`
- L84: `vy = msg.linear.y*1.0`
- L85: `angular = msg.angular.z*1.0     # wait for chang`
- L86: `self.car.set_car_motion(vx, vy, angular)`
- L124: `state.header.frame_id = "joint_states"`
- L126: `state.name = ["back_right_joint", "back_left_joint","front_left_steer_joint","front_left_wheel_joint",`
- L127: `"front_right_steer_joint", "front_right_wheel_joint"]`

### base_node_M1.cpp
- L47: `double wheelbase_ = 0.25;`
- L56: `this->declare_parameter<double>("wheelbase",0.25);`
- L69: `this->get_parameter<double>("wheelbase",wheelbase_);`
- L75: `subscription_ = this->create_subscription<geometry_msgs::msg::Twist>("vel_raw",50,std::bind(&OdomPublisher::handle_vel,this,_1));`
- L76: `odom_publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("odom_raw", 50);`
- L84: `linear_velocity_x_ = msg->linear.x * linear_scale_x_;// scale = 1`
- L85: `linear_velocity_y_ = msg->linear.y * linear_scale_y_;`
- L86: `angular_velocity_z_ = msg->angular.z * angular_scale_;`
- L124: `// linear speed from encoders`
- L125: `odom.twist.twist.linear.x = linear_velocity_x_;`
- L126: `odom.twist.twist.linear.y = linear_velocity_y_;`
- L127: `odom.twist.twist.linear.y = 0.0; // vy = 0.0`
- L131: `// angular speed from encoders`
- L132: `odom.twist.twist.angular.z = angular_velocity_z_;`

### yahboomcar_bringup_M1_launch.py
- L79: `executable='Mcnamu_driver_M1',`
- L84: `executable='base_node_M1',`
