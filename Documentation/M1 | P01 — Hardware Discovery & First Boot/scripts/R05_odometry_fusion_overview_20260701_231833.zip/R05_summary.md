# R05 — Odometry & Sensor Fusion (inventaire statique)

- Container : `youthful_matsumoto`
- Aucun Node lancé, aucun accès aux capteurs ni aux moteurs.
- Résultats basés sur les fichiers présents, non sur des mesures en fonctionnement.

## Fichiers

- `M1_bringup_launch.py` : found
- `imu_filter_param.yaml` : found
- `base_node_M1.cpp` : found
- `Mcnamu_driver_M1.py` : found

## Fichiers EKF potentiels

- `/root/yahboomcar_ros2_ws/yahboomcar_ws/src/yahboomcar_interfaces/yahboomcar_multi/param/ekf_robot2.yaml`
- `/root/yahboomcar_ros2_ws/yahboomcar_ws/src/yahboomcar_interfaces/yahboomcar_multi/param/ekf_robot1.yaml`
- `/root/yahboomcar_ros2_ws/yahboomcar_ws/src/yahboomcar_multi/param/ekf_robot2.yaml`
- `/root/yahboomcar_ros2_ws/yahboomcar_ws/src/yahboomcar_multi/param/ekf_robot1.yaml`
