# R07 — Performance & Resources: baseline

> Mesure ponctuelle et passive, pas un benchmark. Horloge du robot à vérifier.

- CPU (sur 1 seconde) : **1.5 %**
- Cœurs logiques : **4**
- Températures : **{'cpu-thermal (thermal_zone0)': 46.85}**

## Mémoire (KiB)

- MemTotal_KiB: 8257200
- MemFree_KiB: 6541312
- MemAvailable_KiB: 7343312
- SwapTotal_KiB: 1021136
- SwapFree_KiB: 1021136

## Stockage

- `/` : {'total_GiB': 70.01, 'used_GiB': 54.78, 'free_GiB': 12.21, 'used_percent': 78.2}
- `/home/pi` : {'total_GiB': 70.01, 'used_GiB': 54.78, 'free_GiB': 12.21, 'used_percent': 78.2}

## Docker (containers actifs)

```text
youthful_matsumoto	192.168.2.51:5000/ros-humble-m1:1.1.1	Up 2 hours
```

## Docker (instantané CPU/RAM)

```text
youthful_matsumoto	3.30%	0B / 0B	0.00%
```

Notes : données système brutes et diagnostic d'erreur éventuel dans R07_baseline.json.
