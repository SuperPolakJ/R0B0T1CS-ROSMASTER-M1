# R02 — Inventaire ROS 2 (analyse statique)

> Les éléments listés proviennent des fichiers source : ils ne prouvent pas que les Nodes sont actifs.

## Launch M1 principal
- `robot_state_publisher` → `robot_state_publisher`
- `joint_state_publisher` → `joint_state_publisher`
- `joint_state_publisher_gui` → `joint_state_publisher_gui`
- `rviz2` → `rviz2`
- `yahboomcar_bringup` → `Mcnamu_driver_M1`
- `yahboomcar_base_node` → `base_node_M1`
- `imu_filter_madgwick` → `imu_filter_madgwick_node`
- `yahboomcar_ctrl` → `yahboom_joy_M1`
- `joy` → `joy_node`

## Packages ciblés / Topics candidats (à valider)
### yahboomcar_bringup
- Dossier présent : oui
- Fichiers Launch repérés : 5
- Chaînes ressemblant à des Topics : `/Buzzer`, `/JoyState`, `/cmd_vel`, `/ekf_A1_launch`, `/ekf_M1_launch`, `/scan`, `/sllidar_c1_launch`, `/www`, `/yahboomcar_bringup_A1_launch`, `/yahboomcar_bringup_M1_launch`, `/ydlidar_launch`
### yahboomcar_base_node
- Dossier présent : oui
- Fichiers Launch repérés : 0
- Chaînes ressemblant à des Topics : `/geometry_msgs`, `/odom`, `/radians`, `/std`
### yahboomcar_ctrl
- Dossier présent : oui
- Fichiers Launch repérés : 1
- Chaînes ressemblant à des Topics : `/www`
### yahboomcar_laser
- Dossier présent : oui
- Fichiers Launch repérés : 0
- Chaînes ressemblant à des Topics : `/Buzzer`, `/JoyState`, `/cmd_vel`, `/scan`, `/www`
### yahboomcar_nav
- Dossier présent : oui
- Fichiers Launch repérés : 26
- Chaînes ressemblant à des Topics : `/ascamera_hp60c/camera_publisher/depth0/image_raw`, `/ascamera_hp60c/camera_publisher/rgb0/camera_info`, `/ascamera_hp60c/camera_publisher/rgb0/image`, `/bringup_A1_no_odom_launch`, `/bringup_M1_no_odom_launch`, `/bringup_launch`, `/cartographer_bringup_launch`, `/cartographer_launch`, `/complementary_filter`, `/configuration_files`, `/configuration_files/demo_2d`, `/description_launch`, `/downsampled_scan`, `/ekf`, `/github`, `/imu/data`, `/laser_bringup_launch`, `/laser_bringup_no_odom_launch`, `/launch`, `/occupancy_grid_launch`, `/odom`, `/rf2o_laser_odometry`, `/rtabmap_localization_launch`, `/rtabmap_sync_launch`, `/scan`
### yahboomcar_description
- Dossier présent : oui
- Fichiers Launch repérés : 6
- Chaînes ressemblant à des Topics : `/ekf_A1_launch`, `/ekf_M1_launch`, `/www`
### yahboomcar_astra
- Dossier présent : oui
- Fichiers Launch repérés : 0
- Chaînes ressemblant à des Topics : `/Buzzer`, `/Current_point`, `/JoyState`, `/Servo`, `/ascamera_hp60c/camera_publisher/rgb0/image`, `/cmd_vel`, `/image_raw`, `/processed_image`, `/scan`, `/usb_cam/image_raw`, `/www`
### yahboomcar_depth
- Dossier présent : oui
- Fichiers Launch repérés : 1
- Chaînes ressemblant à des Topics : `/Buzzer`, `/JoyState`, `/ascamera_hp60c/camera_publisher/depth0/image_raw`, `/ascamera_hp60c/camera_publisher/rgb0/image`, `/camera`, `/camera/rgb/image_raw/compressed`, `/cmd_vel`, `/hp60c`, `/scan`, `/www`

## Sécurité
- Aucune commande envoyée aux moteurs.
- Aucun Node ROS 2 démarré.
- Aucun port série ouvert.
- Aucun fichier source complet exporté.
