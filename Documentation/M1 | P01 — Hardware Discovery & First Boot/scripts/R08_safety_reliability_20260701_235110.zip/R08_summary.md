# R08 - Inventaire passif de securite / fiabilite

Cette analyse ne valide PAS la securite fonctionnelle du robot.

- Container: `youthful_matsumoto`
- Image: `192.168.2.51:5000/ros-humble-m1:1.1.1`
- Kernel: `6.12.25+rpt-rpi-2712`

## Services (etats)

- `docker.service`: active
- `ssh.service`: active
- `NetworkManager.service`: active
- `yahboom_oled.service`: active

## Indices dans les sources

### motor_driver
- Etat: read
- Lignes: 194; correspondances retenues: 10
  - L57: `self.sub_cmd_vel = self.create_subscription(Twist,"cmd_vel",self.cmd_vel_callback,1)`
  - L59: `self.sub_BUzzer = self.create_subscription(Bool,"Buzzer",self.Buzzercallback,100)`
  - L64: `self.volPublisher = self.create_publisher(Float32,"voltage",100)`
  - L70: `#create timer`
  - L71: `self.timer = self.create_timer(0.1, self.pub_data)`
  - L86: `self.car.set_car_motion(vx, vy, angular)`
  - L119: `battery = Float32()`
  - L134: `battery.data = self.car.get_battery_voltage()*1.0`
  - L171: `# rospy.loginfo("battery: {}".format(battery))`
  - L175: `self.volPublisher.publish(battery)`

### base_node
- Etat: read
- Lignes: 170; correspondances retenues: 1
  - L167: `rclcpp::shutdown();`

### joystick
- Etat: read
- Lignes: 149; correspondances retenues: 8
  - L16: `from sensor_msgs.msg import Joy`
  - L37: `self.pub_cmdVel = self.create_publisher(Twist,'cmd_vel',  10)`
  - L38: `self.pub_Buzzer = self.create_publisher(Bool,"Buzzer",  1)`
  - L45: `self.sub_Joy = self.create_subscription(Joy,'joy', self.buttonCallback,10)`
  - L57: `if not isinstance(joy_data, Joy): return`
  - L73: `#Buzzer`
  - L113: `print("joy control now")`
  - L124: `print("Joy control now")`

### bringup
- Etat: read
- Lignes: 128; correspondances retenues: 1
  - L110: `package='joy',`

## Limites

- Aucun test actif effectue.
- Fonctions de securite a confirmer par inspection et essais dedies, autorises et encadres.
- Verifier manuellement le contenu de l archive avant partage.
